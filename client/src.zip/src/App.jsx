import { Button } from "@/components/ui/button";
import { Example } from "./components/Example";

function App() {
  return <div className="bg-red-500">
    <Button>
      asd
      <Example/>
    </Button>
    </div>;
}

export default App;
